package com.example.minimal_youtube_embed

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
